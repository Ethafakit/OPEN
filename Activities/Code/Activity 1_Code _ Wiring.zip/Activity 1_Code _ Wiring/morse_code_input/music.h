#include <SAMD21turboPWM.h>
TurboPWM pwm;

#define eyes 8
#define buzzer_gnd A3
#define buzzer 4
#define Rcheek 2
#define Lcheek 3
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976

#define one 1000
#define half  600
#define quarter 300
#define quarter_2 150

void win() {
  tone(buzzer, NOTE_C6, quarter_2);
  delay(quarter_2 + 50);
  tone(buzzer, NOTE_E6, quarter_2);
  delay(quarter_2 + 50);
  tone(buzzer, NOTE_G6, quarter_2);
  delay(quarter_2 + 50);
  noTone(0);
}

void lose() {
  tone(buzzer, NOTE_G6, half);
  pwm.analogWrite(eyes, 1000);
  delay(half + 50);
  tone(buzzer, NOTE_E6, half);
  pwm.analogWrite(eyes, 500);
  delay(half + 50);
  tone(buzzer, NOTE_C6, half);
  pwm.analogWrite(eyes, 0);
  delay(half + 50);
  noTone(0);
}

void celebrate() {
  bool blinking = false;
  int notes[] = {NOTE_C6, NOTE_E6, NOTE_G6, NOTE_C6, NOTE_E6, NOTE_G6, NOTE_F6, NOTE_E6, NOTE_D6};
  for ( int i = 0 ; i < 9 ; i++) {
    tone (buzzer, notes[i], quarter_2);
    if (blinking) {
      pwm.analogWrite(eyes, 1000);
    }
    else {
      pwm.analogWrite(eyes, 0);
    }
    blinking = !blinking;
    delay (quarter_2 + 50);
  }
  noTone(0);
}
