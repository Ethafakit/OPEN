#include <SAMD21turboPWM.h>
#define eyes 8
#define buzzer 4
#define buzzer_gnd A3

TurboPWM pwm;
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976

#define one 1000
#define half  600
#define quarter 300
#define quarter_2 150
void beep() {
  tone(buzzer, NOTE_C6, quarter_2);
  delay(quarter_2 + 50);
}
void win() {
  tone(buzzer, NOTE_C6, quarter_2);
  delay(quarter_2 + 50);
  tone(buzzer, NOTE_E6, quarter_2);
  delay(quarter_2 + 50);
  tone(buzzer, NOTE_G6, quarter_2);
  delay(quarter_2 + 50);
  noTone(0);
}

void lose() {
  tone(buzzer, NOTE_G6, half);
  pwm.analogWrite(eyes, 1000);
  delay(half + 50);
  tone(buzzer, NOTE_E6, half);
  pwm.analogWrite(eyes, 500);
  delay(half + 50);
  tone(buzzer, NOTE_C6, half);
  pwm.analogWrite(eyes, 0);
  delay(half + 50);
  noTone(0);
}

void ladder(int degree) {
  if (degree > 5 && degree < 30) {
    tone(buzzer, NOTE_C6, quarter);
  }
  else if (degree > 30 && degree < 60) {
    tone(buzzer, NOTE_E6, quarter);
  }
  else if (degree > 60 && degree < 85) {
    tone(buzzer, NOTE_G6, quarter);
  }
}

void celebrate() {
  bool blinking = false;
  int notes[] = {NOTE_C6, NOTE_E6, NOTE_G6, NOTE_C6, NOTE_E6, NOTE_G6, NOTE_F6, NOTE_E6, NOTE_D6};
  int iterator = 0;
  while (iterator < 9) {
    tone (4, notes[iterator], quarter_2);
    if (blinking) {
      pwm.analogWrite(eyes, 1000);
    }
    else {
      pwm.analogWrite(eyes, 0);
    }
    blinking = !blinking;
    delay (quarter_2 + 50);
    iterator++;
  }
  noTone(0);
}
